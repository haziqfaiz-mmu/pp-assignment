/*
 * Counts the number of occurrences in the portion of the file delimited by the specified indexes and stores them in the
 * map passed as parameter.
 */
void count_words(char *file_name, words_map *map, int start_index, int end_index);
