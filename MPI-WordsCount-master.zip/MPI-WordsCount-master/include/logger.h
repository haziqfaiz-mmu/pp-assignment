#define LOGS_DIR "reports"
#define LINE_WIDTH 120

/*
 * Logs the execution information to a file.
 */
char *log_execution_info(workloads_map *loads_map, words_map *words_map, double *execution_times);
